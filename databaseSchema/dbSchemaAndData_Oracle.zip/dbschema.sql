CREATE TABLE instructor(
  instructor_ID VARCHAR2( 10 ) NOT NULL
  CONSTRAINT instructor_ID_PK PRIMARY KEY,
  
  instructor_PW VARCHAR2( 15 ) NOT NULL,
  instructor_name VARCHAR2( 15 ) NOT NULL,
  
  instructor_admin CHAR
  CONSTRAINT instructor_is_admin CHECK( instructor_admin in( 0, 1 ) )
);

CREATE TABLE course(
  course_ID VARCHAR2( 5 ) NOT NULL
  CONSTRAINT course_ID_PK PRIMARY KEY,
  
  course_name VARCHAR2( 25 ) NOT NULL
);

CREATE TABLE section(
  section_ID VARCHAR2( 5 ) NOT NULL,
  
  course_ID VARCHAR2( 5 ) NOT NULL
  CONSTRAINT section_course_ID_FK REFERENCES course( course_ID ),
  
  instructor_ID VARCHAR2( 10 ) NOT NULL
  CONSTRAINT section_instructor_ID_KF REFERENCES instructor( instructor_ID ),
  
  CONSTRAINT section_PKs PRIMARY KEY( section_ID, course_ID )
);

CREATE TABLE book(
  book_ISBN VARCHAR2( 13 )
  CONSTRAINT book_ID_PK PRIMARY KEY,
  
  section_ID VARCHAR2( 5 ),
  course_ID VARCHAR2( 5 ),
  
  --fictional FKs
  author_ID VARCHAR2( 5 ),
  publisher_ID VARCHAR2( 5 ),
  
  book_title VARCHAR( 25 ),
  book_edition INT,
  
  book_required  CHAR
  CONSTRAINT book_is_required CHECK( book_required in( 0, 1 ) ),
  
  book_recommended CHAR
  CONSTRAINT book_is_recommended CHECK( book_recommended in( 0, 1 ) ),
  
  
  CONSTRAINT book_section_course_ID_FK FOREIGN KEY( section_ID, course_ID )
  REFERENCES section( section_ID, course_ID )
);
