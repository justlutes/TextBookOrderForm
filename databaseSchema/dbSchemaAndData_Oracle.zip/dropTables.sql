DROP TABLE book;
DROP TABLE section;
DROP TABLE instructor;
DROP TABLE course;